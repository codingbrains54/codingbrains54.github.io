
<?php
/**********************************************************************************************
                                 image uploder
**********************************************************************************************/
?>

<?php 
/* Add the media uploader script */
  function my_media_lib_uploader_enqueue() {
    wp_enqueue_media();
    wp_register_script( 'media-lib-uploader-js', get_template_directory_uri()."/js/media_uploader.js", array('jquery') );
    wp_enqueue_script( 'media-lib-uploader-js' );
  }
  add_action('admin_enqueue_scripts', 'my_media_lib_uploader_enqueue');

//start metabox script
function media_metabox(){
  	add_meta_box("media_id","Media","media_metabox_callback","holyday","side","high");
}
add_action("add_meta_boxes","media_metabox");

function media_metabox_callback(){
	$media_value=get_post_meta( get_the_ID(), "__media__metabox",true)
?>
  <input id="image-url" type="text" name="image-url" value="<?php if(!empty($media_value)){echo $media_value;} ?>" />
  <input id="upload-button" type="button" class="button" value="Upload Image" />
  <img id="image-demo" src="<?php echo $media_value; ?>"/>
<?php	} ?>

<?php 
function media_metabox_save_fun(){
 update_post_meta(get_the_ID(), "__media__metabox", $_POST["image-url"]); 	
}
add_action("save_post","media_metabox_save_fun");
?>